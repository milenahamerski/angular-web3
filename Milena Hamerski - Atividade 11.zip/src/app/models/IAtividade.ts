export interface IAtividade {
    getId(): number;
    getNome(): string;
    getDescricao(): string;
    getLocal(): string;
    getDuracao(): number;
}
