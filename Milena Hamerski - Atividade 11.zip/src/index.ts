import Router from "./app/controllers/Router";

const app = new Router();
